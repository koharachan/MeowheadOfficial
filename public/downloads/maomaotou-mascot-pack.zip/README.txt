猫猫头网络科技（广东）有限公司 · 吉祥物立绘包
MAOMAOTOU NETWORK TECHNOLOGY · Mascot pack

许可 / License
  本包内所有文件以 MIT 协议开放：复制、修改、合并、发布、商用、再许可都可以。
  唯一要求是保留下面这段版权与许可声明。

MIT License · Copyright (c) 2026 猫猫头网络科技（广东）有限公司
(MAOMAOTOU NETWORK TECHNOLOGY (GUANGDONG) CO., LTD.)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

  完整文本：https://github.com/koharachan/MeowheadOfficial/blob/main/LICENSE

角色 / Characters
  绪方 寻美（Ogata Hiromi）—— 黑发、猫耳、奶白毛衣、橙色三角鼻。
  tible —— 小吉祥物，同一套配色。

包含 / Contents
  hiromi-idle / wave / think / happy / sleep / oops / peek .webp   720px，透明底
  tible-idle / happy / sleep / alert .webp                          512px，透明底
  hiromi-face.webp                                                  头部特写

用法建议 / Usage
  立绘是透明底 WebP，直接叠在浅色或深色背景上都可；不要加描边或投影，
  会破坏扁平画风。缩到 200px 以下时建议只用头部特写。

商标 / Trademark
  MIT 授予的是版权许可。未经书面同意，请不要用角色形象暗示与你方存在
  并未实际发生的合作或背书。

联系 / Contact
  hello@maomaotou.tech
