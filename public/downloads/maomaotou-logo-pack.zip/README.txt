猫猫头网络科技（广东）有限公司 · 标志资源包
MAOMAOTOU NETWORK TECHNOLOGY · Logo pack

许可 / License
  本包内所有文件以 MIT 协议开放：复制、修改、合并、发布、商用、再许可都可以。
  唯一要求是保留下面这段版权与许可声明。

MIT License · Copyright (c) 2026 猫猫头网络科技（广东）有限公司
(MAOMAOTOU NETWORK TECHNOLOGY (GUANGDONG) CO., LTD.)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

  完整文本：https://github.com/koharachan/MeowheadOfficial/blob/main/LICENSE

包含 / Contents
  mark_primary.svg   主标（墨黑 + 亮橙，透明底）
  mark_mono.svg      单色黑
  mark_reverse.svg   反白（深底使用）
  mark_on_dark.svg   深底版
  mark_open.svg      圆眼变体
  lockup.svg         横排组合（标 + 中英文）
  app_icon.svg       App 图标（圆角容器）
  size_16…128.png    小尺寸位图
  favicon.svg        网站图标

颜色 / Colours
  墨黑 #141210   奶白 #FFF9F1   亮橙 #FF5A1A

小尺寸建议 / Small sizes
  16 / 24 / 32 px 用 mark_mono.svg；App 图标用 app_icon.svg（自带圆角容器）；
  横排组合建议不小于 120px 宽。

商标 / Trademark
  MIT 授予的是版权许可。未经书面同意，请不要用本标志暗示与你方存在
  并未实际发生的合作或背书。

联系 / Contact
  hello@maomaotou.tech
